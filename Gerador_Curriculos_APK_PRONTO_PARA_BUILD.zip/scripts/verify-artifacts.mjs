// Falha com mensagem clara se o EXE/APK não existir ou não contiver os recursos offline. Sem dependências externas.
import {readFile, readdir, stat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const erros = [], avisos = [];
const exigir = (c, m) => { if (!c) erros.push(m); };
const MB = 1024 * 1024;
export function listarZip(buf) {
  let e = -1; for (let i = buf.length - 22; i >= Math.max(0, buf.length - 70000); i--) if (buf.readUInt32LE(i) === 0x06054b50) { e = i; break; }
  if (e < 0) throw new Error('não é um ZIP/APK válido');
  const n = buf.readUInt16LE(e + 10); let p = buf.readUInt32LE(e + 16); const r = {};
  for (let i = 0; i < n; i++) { if (buf.readUInt32LE(p) !== 0x02014b50) throw new Error('diretório ZIP corrompido');
    const nl = buf.readUInt16LE(p + 28), xl = buf.readUInt16LE(p + 30), cl = buf.readUInt16LE(p + 32);
    r[buf.toString('utf8', p + 46, p + 46 + nl)] = buf.readUInt32LE(p + 24); p += 46 + nl + xl + cl; }
  return r;
}
export function listarAsar(buf) {
  const len = buf.readUInt32LE(12), h = JSON.parse(buf.toString('utf8', 16, 16 + len)), r = {};
  (function andar(no, pre) { for (const [k, v] of Object.entries(no.files || {})) v.files ? andar(v, pre + k + '/') : (r[pre + k] = Number(v.size)); })(h, '');
  return r;
}
async function achar(dir, re) { try { return (await readdir(dir)).filter(f => re.test(f)).map(f => path.join(dir, f)); } catch { return []; } }
export async function verificar(alvo, raiz = process.cwd(), exigirIbge = process.env.REQUIRE_IBGE === '1') {
  erros.length = 0;
  const recursos = (lista, base) => {
    exigir(base + 'index.html' in lista, 'falta index.html no pacote');
    exigir((lista[base + 'vendor/jspdf.umd.min.js'] || 0) > 100_000, 'jsPDF ausente ou vazio no pacote (PDF direto offline não funcionaria)');
    exigir(base + 'cbo.js' in lista, 'falta cbo.js no pacote');
    exigir(base + 'municipios.js' in lista, 'falta municipios.js no pacote');
    if (exigirIbge) exigir((lista[base + 'municipios.js'] || 0) > 100_000, 'municipios.js sem a lista do IBGE (pacote sem municípios offline)');
  };
  if (alvo === 'windows') {
    const dir = path.join(raiz, 'dist-windows'), exes = await achar(dir, /^Gerador-Curriculos-Setup-.*\.exe$/);
    exigir(exes.length === 1, `esperado 1 instalador Gerador-Curriculos-Setup-*.exe em dist-windows, encontrado ${exes.length}`);
    for (const f of exes) { const b = await readFile(f); exigir(b.length > 30 * MB, `instalador pequeno demais (${(b.length / MB).toFixed(1)} MB; mínimo 30 MB)`); exigir(b.toString('latin1', 0, 2) === 'MZ', 'o arquivo não é um executável do Windows (cabeçalho MZ ausente)'); }
    const asar = path.join(dir, 'win-unpacked', 'resources', 'app.asar');
    try { recursos(listarAsar(await readFile(asar)), 'web/'); } catch (e) { erros.push('não foi possível ler ' + asar + ': ' + e.message); }
  } else if (alvo === 'android') {
    const apks = await achar(path.join(raiz, 'android', 'app', 'build', 'outputs', 'apk', 'debug'), /\.apk$/);
    exigir(apks.length === 1, `esperado 1 APK em android/app/build/outputs/apk/debug, encontrado ${apks.length}`);
    for (const f of apks) { const b = await readFile(f); exigir(b.length > 2 * MB, `APK pequeno demais (${(b.length / MB).toFixed(1)} MB)`);
      try { const l = listarZip(b); exigir('AndroidManifest.xml' in l && 'classes.dex' in l, 'APK sem AndroidManifest.xml/classes.dex'); recursos(l, 'assets/public/'); } catch (e) { erros.push('APK ilegível: ' + e.message); } }
  } else erros.push('uso: node scripts/verify-artifacts.mjs windows|android [pasta]');
  return [...erros];
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  const e = await verificar(process.argv[2], process.argv[3] ? path.resolve(process.argv[3]) : process.cwd());
  if (e.length) { console.error('VERIFICAÇÃO FALHOU (' + process.argv[2] + '):\n - ' + e.join('\n - ')); process.exit(1); }
  console.log('Artefato ' + process.argv[2] + ' verificado: arquivo gerado e recursos offline presentes.');
}
