// Ajusta versionName/versionCode do projeto Android gerado. Falha com mensagem clara se não encontrar os campos.
import {readFile, writeFile} from 'node:fs/promises';
const arq = process.argv[2] || 'android/app/build.gradle';
const versao = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8')).version;
const codigo = process.env.VERSION_CODE || '1';
let g = await readFile(arq, 'utf8');
if (!/versionCode\s+\d+/.test(g) || !/versionName\s+"[^"]*"/.test(g)) { console.error(`versionCode/versionName não encontrados em ${arq}.`); process.exit(1); }
g = g.replace(/versionCode\s+\d+/, `versionCode ${codigo}`).replace(/versionName\s+"[^"]*"/, `versionName "${versao}"`);
await writeFile(arq, g); console.log(`Android: versionName ${versao}, versionCode ${codigo}.`);
