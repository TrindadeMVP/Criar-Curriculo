// Prepara os recursos offline que entram nos instaladores: jsPDF, municípios (IBGE) e CBO.
import {copyFile, mkdir, stat} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {importarIbge} from './import-ibge.mjs';
import {importarCbo} from './import-cbo.mjs';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const vendor = path.join(ROOT, 'web', 'vendor');
await mkdir(vendor, {recursive: true});
const origem = path.join(ROOT, 'node_modules', 'jspdf', 'dist', 'jspdf.umd.min.js');
try { if ((await stat(origem)).size < 100_000) throw new Error('arquivo pequeno demais'); }
catch (e) { console.error('jsPDF não encontrado em node_modules (' + e.message + '). Execute "npm install" antes de "npm run assets".'); process.exit(1); }
await copyFile(origem, path.join(vendor, 'jspdf.umd.min.js'));
try { await copyFile(path.join(ROOT, 'node_modules', 'jspdf', 'LICENSE'), path.join(vendor, 'LICENSE-jspdf.txt')); } catch { /* opcional */ }
console.log('jsPDF incorporado em web/vendor (PDF direto, offline).');
try { await importarIbge(); await importarCbo(); } catch (e) { console.error(e.message); process.exit(1); }
