// Importador da CBO -> web/cbo.js. Lê data/cbo/*.csv|txt|json (CSV oficial "CODIGO;TITULO", inclusive sinônimos).
import {readFile, writeFile, readdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export function decodificar(buf) {
  try { return new TextDecoder('utf-8', {fatal: true}).decode(buf); } catch { return new TextDecoder('windows-1252').decode(buf); }
}
export function lerTitulos(texto) {
  const t = String(texto).replace(/^\uFEFF/, '').trim();
  let a;
  if (t[0] === '[') a = JSON.parse(t).map(x => Array.isArray(x) ? x[x.length - 1] : (x && typeof x === 'object' ? (x.titulo || x.title || x.nome) : x));
  else a = t.split(/\r?\n/).map(l => { const f = l.split(/;|\t/); return f[f.length - 1]; }).filter((x, i) => !(i === 0 && /^["']?(t[ií]tulo|titulo|ocupa)/i.test(x)));
  return a.map(x => String(x || '').replace(/^["']|["']$/g, '').replace(/\s+/g, ' ').trim())
    .filter(x => x.length > 2 && !/^\d+$/.test(x))
    .map(x => x === x.toUpperCase() && /[A-ZÀ-Ú]/.test(x) ? x.charAt(0) + x.slice(1).toLowerCase() : x);
}
export async function importarCbo({dir = path.join(ROOT, 'data', 'cbo'), out = path.join(ROOT, 'web', 'cbo.js'), minimo = Number(process.env.CBO_MIN || 10),
  exigir = process.env.REQUIRE_CBO === '1', log = console} = {}) {
  let arqs = [];
  try { arqs = (await readdir(dir)).filter(f => /\.(csv|txt|json)$/i.test(f)).sort(); } catch { /* pasta ausente */ }
  if (!arqs.length) {
    const m = 'CBO: nenhum arquivo em data/cbo/ (veja data/cbo/LEIA-ME.md). O app usa as sugestões internas e permite importar a CBO.';
    if (exigir) throw new Error(m); log.warn?.(m); return {total: 0, arquivos: []};
  }
  const todos = [];
  for (const f of arqs) {
    try { todos.push(...lerTitulos(decodificar(await readFile(path.join(dir, f))))); }
    catch (e) { throw new Error(`CBO: não foi possível ler ${f}: ${e.message}`); }
  }
  const lista = [...new Set(todos)].sort((a, b) => a.localeCompare(b, 'pt'));
  if (lista.length < minimo) throw new Error(`CBO: apenas ${lista.length} títulos válidos em ${arqs.join(', ')} (mínimo ${minimo}). Confira o formato.`);
  await writeFile(out, 'window.__cbo = ' + JSON.stringify(lista) + ';\n');
  log.log?.(`CBO: ${lista.length} títulos incorporados de ${arqs.length} arquivo(s).`); return {total: lista.length, arquivos: arqs};
}
if (process.argv[1] === fileURLToPath(import.meta.url)) importarCbo().catch(e => { console.error(e.message); process.exit(1); });
