// Verifica a sintaxe de todos os <script> embutidos em web/index.html e impede recursos externos.
import {readFile} from 'node:fs/promises';
import {writeFile, rm} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import path from 'node:path'; import os from 'node:os';
const html = await readFile(new URL('../web/index.html', import.meta.url), 'utf8');
let bad = 0;
const ext = html.match(/<(?:script|link)[^>]+(?:src|href)=["']https?:\/\/[^"']+/g) || [];
if (ext.length) { console.error('Recursos externos proibidos (quebram o modo offline):', ext); bad++; }
const scripts = [...html.matchAll(/<script(?![^>]*\bsrc=)[^>]*>([\s\S]*?)<\/script>/g)].map(m => m[1]);
for (const [i, code] of scripts.entries()) {
  const f = path.join(os.tmpdir(), `inline-${i}.cjs`); await writeFile(f, code);
  try { execFileSync(process.execPath, ['--check', f], {stdio: 'pipe'}); } catch (e) { console.error(`Erro de sintaxe no script embutido #${i}:\n` + e.stderr); bad++; }
  await rm(f);
}
if (/AIza|sk-ant-|api[_-]?key\s*[:=]\s*["'][^"']{12,}/i.test(html)) { console.error('Possível chave de API no HTML.'); bad++; }
console.log(`${scripts.length} scripts embutidos verificados.`); process.exit(bad ? 1 : 0);
