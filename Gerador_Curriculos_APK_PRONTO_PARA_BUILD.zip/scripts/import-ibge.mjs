// Importador automatizado dos municípios do IBGE -> web/municipios.js (uso offline).
// Tenta a API oficial com novas tentativas; se falhar, usa a cópia local data/ibge/municipios.json.
import {readFile, writeFile, mkdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const IBGE_API = 'https://servicodados.ibge.gov.br/api/v1/localidades/municipios?orderBy=nome';
const UFS = 27;

export function agrupar(dados, minTotal = 5500) {
  const o = {};
  for (const m of dados) {
    const uf = m?.microrregiao?.mesorregiao?.UF?.sigla || m?.['regiao-imediata']?.['regiao-intermediaria']?.UF?.sigla;
    if (uf && m.nome) (o[uf] ??= []).push(String(m.nome).trim());
  }
  return validar(o, minTotal);
}
export function validar(o, minTotal = 5500) {
  const ufs = Object.keys(o).length;
  if (ufs !== UFS) throw new Error(`Dados incompletos: ${ufs} UFs (esperado ${UFS}).`);
  let total = 0;
  for (const k of Object.keys(o)) { o[k] = [...new Set(o[k])].sort((a, b) => a.localeCompare(b, 'pt-BR')); total += o[k].length; }
  if (total < minTotal) throw new Error(`Dados incompletos: ${total} municípios (mínimo ${minTotal}).`);
  return o;
}
const dormir = ms => new Promise(r => setTimeout(r, ms));

export async function importarIbge({
  api = process.env.IBGE_API || IBGE_API,
  out = path.join(ROOT, 'web', 'municipios.js'),
  copia = path.join(ROOT, 'data', 'ibge', 'municipios.json'),
  tentativas = 4, esperaMs = 2000, timeoutMs = 60000,
  minTotal = Number(process.env.IBGE_MIN_TOTAL || 5500),
  exigir = process.env.REQUIRE_IBGE === '1', log = console,
} = {}) {
  let dados = null, fonte = '', ultimo = null;
  for (let i = 1; i <= tentativas && !dados; i++) {
    try {
      const r = await fetch(api, {signal: AbortSignal.timeout(timeoutMs)});
      if (!r.ok) throw new Error('HTTP ' + r.status);
      dados = agrupar(await r.json(), minTotal); fonte = 'API do IBGE';
    } catch (e) { ultimo = e; log.warn?.(`IBGE: tentativa ${i}/${tentativas} falhou (${e.message}).`); if (i < tentativas) await dormir(esperaMs * i); }
  }
  if (dados) { await mkdir(path.dirname(copia), {recursive: true}); await writeFile(copia, JSON.stringify(dados)); }
  else {
    try { dados = validar(JSON.parse(await readFile(copia, 'utf8')), minTotal); fonte = 'cópia local data/ibge/municipios.json'; log.warn?.('IBGE: usando a cópia local (API indisponível).'); }
    catch { /* sem cópia válida */ }
  }
  if (!dados) {
    const msg = `IBGE indisponível e sem cópia local válida (${ultimo?.message || 'sem detalhes'}).`;
    if (exigir) throw new Error(msg + ' Rode o fluxo de novo ou coloque data/ibge/municipios.json no repositório.');
    log.warn?.(msg + ' O app seguirá com digitação livre e importação manual.'); return {fonte: 'nenhuma', total: 0};
  }
  await writeFile(out, 'window.__municipios = ' + JSON.stringify(dados) + ';\n');
  const total = Object.values(dados).reduce((n, a) => n + a.length, 0);
  log.log?.(`IBGE: ${total} municípios incorporados (${fonte}).`); return {fonte, total};
}
if (process.argv[1] === fileURLToPath(import.meta.url)) importarIbge().catch(e => { console.error(e.message); process.exit(1); });
