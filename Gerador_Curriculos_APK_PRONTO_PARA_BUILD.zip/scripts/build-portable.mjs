// Compila a edição Windows portátil usando somente Go + Node e arquivos web existentes.
import {cp, mkdir, rm, stat, readFile, writeFile} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const from = path.join(root, 'web'), to = path.join(root, 'portable', 'windows', 'web');
await rm(to, {recursive: true, force: true});
await cp(from, to, {recursive: true});
// Sem instalação NPM no ambiente local: arquivo neutro evita erro 404; o app usará impressão PDF.
const pdfLocal = path.join(to, 'vendor', 'jspdf.umd.min.js');
try { await stat(pdfLocal); } catch { await mkdir(path.dirname(pdfLocal), {recursive: true}); await writeFile(pdfLocal, '/* jsPDF ausente: use Imprimir > Salvar como PDF. */\n'); }
await mkdir(path.join(root,'dist-portable'), {recursive: true});
const output=path.join(root,'dist-portable','Gerador-Curriculos-Windows-PORTATIL.exe');
const go = spawnSync('go',['build','-trimpath','-ldflags=-s -w','-o',output,'.'],{cwd:path.join(root,'portable','windows'),stdio:'inherit',env:{...process.env,GOOS:'windows',GOARCH:'amd64',CGO_ENABLED:'0',GOTOOLCHAIN:'local'}});
if (go.error || go.status!==0) {console.error('Falha na compilação Go portátil:',go.error||go.status);process.exit(1)}
const st=await stat(output),magic=(await readFile(output)).subarray(0,2).toString('ascii');
if(st.size<1024*1024||magic!=='MZ'){console.error('Executável Windows inválido');process.exit(1)}
console.log(`EXE portátil compilado: ${output} (${(st.size/1024/1024).toFixed(1)} MB). Abre o navegador padrão; não é Electron.`);
