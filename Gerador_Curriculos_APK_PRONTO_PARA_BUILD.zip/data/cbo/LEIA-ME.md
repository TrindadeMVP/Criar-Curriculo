# Dados da CBO (Classificação Brasileira de Ocupações)

Coloque aqui os arquivos oficiais da CBO (por exemplo, `CBO2002 - Ocupacao.csv` e `CBO2002 - Sinonimo.csv`),
obtidos no portal da CBO do Ministério do Trabalho e Emprego (área de downloads). O endereço exato do portal
e o formato dos arquivos podem mudar; não foi possível baixá-los automaticamente nem confirmá-los no ambiente de desenvolvimento.

Formatos aceitos: CSV/TXT com `CODIGO;TITULO` (UTF-8 ou Windows-1252; a primeira linha de cabeçalho é ignorada) ou JSON com lista de títulos.
O comando `npm run assets` (e o GitHub Actions) converte tudo em `web/cbo.js`. Sem arquivos aqui, o app usa as sugestões internas
e continua permitindo digitar qualquer profissão ou importar a CBO pela própria tela "Objetivo".
