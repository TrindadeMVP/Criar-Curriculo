const {app, BrowserWindow, shell} = require('electron');
const path = require('path');
const appUrl = path.join(__dirname, '..', 'web', 'index.html');
let win = null;
if (!app.requestSingleInstanceLock()) app.quit();
else {
  app.on('second-instance', () => { if (win) { if (win.isMinimized()) win.restore(); win.focus(); } });
  const createWindow = () => {
    win = new BrowserWindow({
      width: 1340, height: 900, minWidth: 720, minHeight: 580,
      title: 'Gerador de Currículos', show: false, autoHideMenuBar: true,
      webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true }
    });
    win.loadFile(appUrl);
    win.once('ready-to-show', () => win.show());
    win.on('closed', () => { win = null; });
    win.webContents.session.setPermissionRequestHandler((_wc, _perm, cb) => cb(false));
    win.webContents.setWindowOpenHandler(({url}) => {
      if (/^https:\/\//.test(url)) shell.openExternal(url);
      return {action: 'deny'};
    });
    win.webContents.on('will-navigate', (event, url) => {
      if (!url.startsWith('file://')) event.preventDefault();
    });
  };
  app.whenReady().then(() => {
    createWindow();
    app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
  });
  app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
}
