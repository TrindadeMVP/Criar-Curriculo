"""Teste do PDF gerado DIRETAMENTE pelo jsPDF. Só roda onde web/vendor/jspdf.umd.min.js existir (após `npm run assets`).
Sem jsPDF sai com código 3 ("PULADO"), sem afirmar nada. Uso: python3 tests/pdf_direto.py"""
import sys, os, json
from pathlib import Path
from playwright.sync_api import sync_playwright
from pypdf import PdfReader
sys.path.insert(0, str(Path(__file__).parent)); from dados import DATA
ROOT = Path(__file__).resolve().parent.parent
OUT = Path(os.environ.get('E2E_OUT', '/tmp/out')) / 'pdf'; OUT.mkdir(parents=True, exist_ok=True)
if not (ROOT / 'web/vendor/jspdf.umd.min.js').exists(): print('PULADO: jsPDF ausente (rode npm install && npm run assets).'); sys.exit(3)
(OUT / 'd.json').write_text(json.dumps(DATA)); falhas = []
with sync_playwright() as p:
    b = p.chromium.launch(); ctx = b.new_context(viewport={'width': 1366, 'height': 900}, accept_downloads=True); pg = ctx.new_page(); erros = []
    pg.on('pageerror', lambda e: erros.append(str(e))); pg.goto((ROOT / 'web/index.html').as_uri()); pg.wait_for_timeout(500)
    if not pg.evaluate('!!(window.jspdf&&window.jspdf.jsPDF)'): print('FALHA: jsPDF não carregou no app'); sys.exit(1)
    pg.locator('#nav button').nth(8).click(); pg.set_input_files('#imp', str(OUT / 'd.json')); pg.wait_for_timeout(300); pg.locator('#nav button').nth(8).click()
    for t in [o for o in pg.eval_on_selector_all('select[data-k=tpl] option', 'o=>o.map(x=>x.value)')]:
        pg.select_option('select[data-k=tpl]', t); pg.wait_for_timeout(60)
        try:
            with pg.expect_download(timeout=20000) as d: pg.click('#pdf')
            f = OUT / f'cv_{t}.pdf'; d.value.save_as(str(f)); r = PdfReader(str(f)); txt = ' '.join(x.extract_text() or '' for x in r.pages)
            ok = len(r.pages) >= 1 and 'Figueiredo' in txt.replace('\n', ' ') and txt.count('Empresa Exemplo') >= 5
            print(('PASS' if ok else 'FAIL'), f'PDF {t}: {len(r.pages)} página(s), {len(txt)} caracteres'); ok or falhas.append(t)
        except Exception as e: print('FAIL PDF', t, str(e)[:120]); falhas.append(t)
    if erros: print('Erros JS:', erros); falhas.append('js')
    b.close()
print('Falhas:', falhas or 'nenhuma'); sys.exit(1 if falhas else 0)
