"""Teste ponta a ponta REAL no Chromium (Playwright). Uso: python3 tests/e2e.py [pasta_web]
Cria cópias temporárias do app com dados FICTÍCIOS/MOCK (IBGE falso, CBO fictícia) e não altera web/."""
import sys, os, io, json, shutil, subprocess, threading, time, zipfile, http.server
from pathlib import Path
from playwright.sync_api import sync_playwright
import docx
from PIL import Image
sys.path.insert(0, str(Path(__file__).parent)); from dados import DATA
ROOT = Path(__file__).resolve().parent.parent
WEB = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else ROOT / 'web'
OUT = Path(os.environ.get('E2E_OUT', '/tmp/out')); shutil.rmtree(OUT, ignore_errors=True); OUT.mkdir(parents=True)
fails, ok = [], []
def check(n, c, extra=''):
    (ok if c else fails).append(n); print(('PASS ' if c else 'FAIL ') + n + ('' if c or extra == '' else ' :: ' + str(extra)), flush=True)
def node(code):
    r = subprocess.run(['node', '--input-type=module', '-e', code], cwd=ROOT, capture_output=True, text=True); check('node: ' + code[:40], r.returncode == 0, r.stderr[-300:]); return r
def site(nome, ibge=True, cbo='fixture'):
    d = OUT / nome; shutil.copytree(WEB, d)
    (d / 'vendor').mkdir(exist_ok=True)
    if not (d / 'vendor' / 'jspdf.umd.min.js').exists(): (d / 'vendor' / 'jspdf.umd.min.js').write_text('window.__stubJsPdf=true;')
    if ibge: node(f"import {{importarIbge}} from './scripts/import-ibge.mjs'; await importarIbge({{api:'http://127.0.0.1:{PORT}/m',out:'{d}/municipios.js',copia:'{OUT}/c.json',minTotal:100,tentativas:1,log:{{}}}})")
    else: (d / 'municipios.js').write_text('window.__municipios = null;')
    if cbo == 'fixture':
        (OUT / 'cbo_dir').mkdir(exist_ok=True); shutil.copy(ROOT / 'tests/fixtures/cbo_ficticia.csv', OUT / 'cbo_dir')
        node(f"import {{importarCbo}} from './scripts/import-cbo.mjs'; await importarCbo({{dir:'{OUT}/cbo_dir',out:'{d}/cbo.js',minimo:10,log:{{}}}})")
    elif cbo == 'grande':
        w = ['Auxiliar', 'Operador', 'Técnico', 'Analista', 'Assistente', 'Montador', 'Inspetor', 'Supervisor']; m = ['de produção', 'de máquinas', 'em eletrônica', 'de logística', 'de qualidade', 'agrícola', 'de laboratório']
        L = sorted({f'{a} {b} {i}' for i in range(300) for a in w for b in m})[:15000]; (d / 'cbo.js').write_text('window.__cbo = ' + json.dumps(L, ensure_ascii=False) + ';')
    else: (d / 'cbo.js').write_text('window.__cbo = null;')
    return (d / 'index.html').as_uri()
# servidor IBGE FALSO
UFS = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split()
FAKE = json.dumps([{'nome': f'Cidade {u} {k}', 'microrregiao': {'mesorregiao': {'UF': {'sigla': u}}}} for u in UFS for k in range(6)]).encode()
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(s): s.send_response(200); s.end_headers(); s.wfile.write(FAKE)
    def log_message(*a): pass
srv = http.server.HTTPServer(('127.0.0.1', 0), H); PORT = srv.server_address[1]; threading.Thread(target=srv.serve_forever, daemon=True).start()
buf = io.BytesIO(); Image.new('RGB', (600, 800), (40, 120, 160)).save(buf, 'PNG'); (OUT / 'foto.png').write_bytes(buf.getvalue())
(OUT / 'd.json').write_text(json.dumps(DATA))
URL_A = site('A'); URL_G = site('G', cbo='grande'); URL_N = site('N', ibge=False, cbo='nenhuma')
def novo(b, vp, mobile, bloquear=True):
    ctx = b.new_context(viewport=vp, accept_downloads=True, is_mobile=mobile, has_touch=mobile, service_workers='block'); ext = []
    if bloquear: ctx.route(lambda u: u.startswith('http'), lambda r: (ext.append(r.request.url), r.abort()))
    pg = ctx.new_page(); errs = []
    pg.on('pageerror', lambda e: errs.append(str(e))); pg.on('console', lambda m: errs.append(m.text) if m.type == 'error' and 'ERR_FAILED' not in m.text and 'net::' not in m.text else None)
    return ctx, pg, errs, ext
with sync_playwright() as p:
    b = p.chromium.launch()
    for label, vp, mobile in [('desktop', {'width': 1366, 'height': 900}, False), ('celular', {'width': 390, 'height': 844}, True)]:
        ctx, pg, errs, ext = novo(b, vp, mobile); pg.goto(URL_A); pg.wait_for_timeout(400)
        navs = pg.locator('#nav button'); check(f'[{label}] 9 etapas', navs.count() == 9, navs.count())
        for i in range(9): navs.nth(i).click(); pg.wait_for_timeout(50); check(f'[{label}] etapa {i+1} renderiza', len(pg.inner_text('#step')) > 20)
        navs.nth(0).click(); pg.fill('input[data-k=nome]', 'joão da silva'); pg.dispatch_event('input[data-k=nome]', 'change')
        check(f'[{label}] nome formatado', pg.input_value('input[data-k=nome]') == 'João da Silva')
        pg.fill('input[data-k=tel]', '17999999999'); check(f'[{label}] telefone formatado', pg.input_value('input[data-k=tel]') == '(17) 99999-9999')
        pg.fill('input[data-k=email]', 'a@gmial.com'); check(f'[{label}] sugestão de e-mail', 'gmail.com' in pg.inner_text('[data-fb=email]'))
        # municípios (IBGE mock embutido) e CBO
        pg.select_option('select[data-k=uf]', 'SP'); pg.fill('#cid', 'Cidade SP'); pg.wait_for_timeout(80)
        cb = pg.locator('#sg [data-city]'); check(f'[{label}] sugestão de municípios (lista embutida)', cb.count() >= 3, cb.count()); cb.first.click()
        check(f'[{label}] município escolhido', pg.evaluate('S.cid') == 'Cidade SP 0' and pg.evaluate('S.cidade') == 'Cidade SP 0, SP', pg.evaluate('S.cidade'))
        check(f'[{label}] mensagem IBGE offline', 'disponível offline' in pg.inner_text('#step'))
        navs.nth(1).click(); pg.fill('#cargo', 'eletron'); pg.wait_for_timeout(80)
        oc = pg.locator('#occ [data-occ]').all_inner_texts(); check(f'[{label}] CBO: busca sem acento acha "Técnico em eletrônica"', 'Técnico em eletrônica' in oc, oc)
        pg.locator('#occ [data-occ]', has_text='Técnico em eletrônica').first.click(); check(f'[{label}] CBO: seleção grava cargo', pg.evaluate('S.cargo') == 'Técnico em eletrônica', pg.evaluate('S.cargo'))
        pg.fill('#cargo', 'Barista de cafés especiais'); check(f'[{label}] campo personalizado preservado', pg.evaluate('S.cargo') == 'Barista de cafés especiais')
        pg.fill('#cargo', 'aux enf'); pg.wait_for_timeout(60); check(f'[{label}] busca por palavras parciais', 'Auxiliar de enfermagem' in pg.locator('#occ [data-occ]').all_inner_texts())
        # dados longos + foto
        navs.nth(8).click(); pg.set_input_files('#imp', str(OUT / 'd.json')); pg.wait_for_timeout(300)
        navs.nth(0).click(); pg.set_input_files('#ph', str(OUT / 'foto.png')); pg.wait_for_timeout(400); check(f'[{label}] foto carregada', pg.evaluate('!!S.foto'))
        navs.nth(8).click(); tpls = pg.eval_on_selector_all('select[data-k=tpl] option', 'o=>o.map(x=>x.value)'); check(f'[{label}] 15 modelos', len(tpls) == 15, len(tpls))
        for t in tpls:
            pg.select_option('select[data-k=tpl]', t); pg.wait_for_timeout(60)
            r = pg.evaluate("""()=>{const cv=document.getElementById('cv'),b=cv.getBoundingClientRect();let bad=[];cv.querySelectorAll('*').forEach(e=>{const r=e.getBoundingClientRect();if(r.width&&(r.right>b.right+2||r.left<b.left-2))bad.push(e.tagName+'.'+e.className)});return {bad:bad.slice(0,4),doc:document.documentElement.scrollWidth-document.documentElement.clientWidth}}""")
            check(f'[{label}] modelo {t}: sem estouro lateral', not r['bad'] and r['doc'] <= 1, r)
            if not mobile:
                pg.locator('#cv').screenshot(path=str(OUT / f'prev_{t}.png'))
                with pg.expect_download() as d: pg.click('#docx')
                f = OUT / f'cv_{t}.docx'; d.value.save_as(str(f)); doc = docx.Document(str(f)); txt = '\n'.join(x.text for x in doc.paragraphs) + ''.join(c.text for tb in doc.tables for c in tb._cells)
                med = [n for n in zipfile.ZipFile(f).namelist() if 'media' in n]
                check(f'[{label}] Word {t}: nome, 5 experiências e foto', 'Figueiredo' in txt and txt.count('Empresa Exemplo') == 5 and len(med) >= 1, (len(txt), med))
        nome = pg.evaluate('S.nome'); pg.reload(); pg.wait_for_timeout(400); check(f'[{label}] dados persistem ao recarregar', pg.evaluate('S.nome') == nome and nome != '', nome)
        check(f'[{label}] sem erros JS nem violações de CSP', not errs, errs); check(f'[{label}] offline: nenhuma requisição externa', not ext, ext)
        ctx.close()
    # CSP: script local carregado e nenhum recurso remoto
    ctx, pg, errs, ext = novo(b, {'width': 1200, 'height': 800}, False); pg.goto(URL_A); pg.wait_for_timeout(300)
    check('CSP ativa e script local (vendor) carrega', pg.evaluate("!!document.querySelector('meta[http-equiv=Content-Security-Policy]') && (window.__stubJsPdf===true || !!window.jspdf)")); ctx.close()
    # exportar/importar, múltiplos currículos, desfazer, versões, tema
    ctx, pg, errs, ext = novo(b, {'width': 1366, 'height': 900}, False); pg.goto(URL_A); pg.wait_for_timeout(300)
    pg.locator('#nav button').nth(8).click(); pg.set_input_files('#imp', str(OUT / 'd.json')); pg.wait_for_timeout(300); pg.locator('#nav button').nth(8).click(); antes = pg.evaluate('sj()')
    with pg.expect_download() as d: pg.click('#jsonx')
    jf = OUT / 'export.json'; d.value.save_as(str(jf)); ex = json.loads(jf.read_text()); check('exportar: JSON válido com nome e 5 experiências', ex['nome'] == DATA['nome'] and len(ex['jobs']) == 5)
    pg.locator('#nav button').nth(8).click(); pg.click('#reset'); pg.click('#reset'); pg.wait_for_timeout(200); check('limpar tudo (confirmação em 2 toques)', pg.evaluate('S.nome') == '')
    pg.locator('#nav button').nth(8).click(); pg.set_input_files('#imp', str(jf)); pg.wait_for_timeout(300); check('importar: dados restaurados idênticos', pg.evaluate('sj()') == antes)
    (OUT / 'ruim.json').write_text('{isto não é json'); pg.locator('#nav button').nth(8).click(); pg.set_input_files('#imp', str(OUT / 'ruim.json')); pg.wait_for_timeout(200); check('importar arquivo inválido: mensagem de erro', 'inválido' in pg.inner_text('#note') and pg.evaluate('sj()') == antes)
    (OUT / 'mal.json').write_text(json.dumps({'nome': 5, 'jobs': 'x', '__proto__': {'x': 1}, 'fs': 'a'})); pg.locator('#nav button').nth(8).click(); pg.set_input_files('#imp', str(OUT / 'mal.json')); pg.wait_for_timeout(200)
    check('importar JSON com tipos errados não corrompe o estado', pg.evaluate('typeof S.nome==="string" && Array.isArray(S.jobs) && typeof S.fs==="number" && ({}).x===undefined'))
    pg.locator('#nav button').nth(8).click(); pg.set_input_files('#imp', str(jf)); pg.wait_for_timeout(200); pg.locator('#nav button').nth(8).click(); pg.click('#vsave'); pg.wait_for_timeout(100); check('versões: salvar versão', pg.locator('.vl li button[data-vr]').count() >= 1)
    n0 = pg.locator('#rsel option').count(); pg.click('#rnew'); pg.wait_for_timeout(150); check('múltiplos currículos: novo', pg.locator('#rsel option').count() == n0 + 1)
    pg.fill('#rname', 'Segundo'); pg.click('#rdup'); pg.wait_for_timeout(150); check('múltiplos currículos: duplicar', pg.locator('#rsel option').count() == n0 + 2)
    pg.click('#rdel'); pg.click('#rdel'); pg.wait_for_timeout(150); check('múltiplos currículos: excluir (2 toques)', pg.locator('#rsel option').count() == n0 + 1)
    pg.locator('#nav button').nth(0).click(); pg.fill('input[data-k=nome]', 'Teste Undo'); pg.wait_for_timeout(900); pg.fill('input[data-k=nome]', 'Teste Redo'); pg.wait_for_timeout(900)
    pg.click('#undo'); check('desfazer', pg.evaluate('S.nome') == 'Teste Undo', pg.evaluate('S.nome')); pg.click('#redo'); check('refazer', pg.evaluate('S.nome') == 'Teste Redo')
    t0 = pg.evaluate('document.documentElement.dataset.theme||""'); pg.click('#theme'); check('tema claro/escuro alterna', pg.evaluate('document.documentElement.dataset.theme||""') != t0)
    check('exportar/importar: sem erros JS', not errs, errs); ctx.close()
    # desempenho com 15.000 títulos
    ctx, pg, errs, ext = novo(b, {'width': 1200, 'height': 800}, False); pg.goto(URL_G); pg.wait_for_timeout(500)
    r = pg.evaluate("""()=>{S.cargo='montador agr';const t0=performance.now();const first=occHTML();const t1=performance.now();let worst=0,n=0;for(const q of ['xyzq','zzzz yy','montador de lab','inspetor 29','tecnico elet 7']){S.cargo=q;const a=performance.now();const h=occHTML();worst=Math.max(worst,performance.now()-a);n+=(h.match(/data-occ/g)||[]).length}return {n:cboList().length,first:t1-t0,worst,hits:n,firstHits:(first.match(/data-occ/g)||[]).length}}""")
    check(f'desempenho: {r["n"]} títulos CBO; 1ª busca (cria índice) {r["first"]:.1f} ms; pior busca {r["worst"]:.1f} ms', r['n'] == 15000 and r['firstHits'] > 0 and r['hits'] > 0 and r['first'] < 300 and r['worst'] < 50, r)
    pg.locator('#nav button').nth(1).click(); t0 = time.time(); pg.fill('#cargo', 'auxiliar de produção 1'); pg.wait_for_timeout(50); check('digitação com 15 mil títulos responde (<1 s)', time.time() - t0 < 1.0 and pg.locator('#occ [data-occ]').count() <= 12); ctx.close()
    # sem dados embutidos: importar CBO pela tela, arquivo inválido, persistência
    ctx, pg, errs, ext = novo(b, {'width': 1200, 'height': 800}, False); pg.goto(URL_N); pg.wait_for_timeout(400)
    pg.locator('#nav button').nth(1).click(); check('sem CBO: aparece a opção de importar', 'importar a lista da CBO' in pg.inner_text('#step'))
    pg.set_input_files('#cbo', str(ROOT / 'tests/fixtures/cbo_ficticia.csv')); pg.wait_for_timeout(300); n_app = pg.evaluate('cboList().length')
    check('importar CBO (CSV Latin-1) pela tela', n_app == 30 and 'Base CBO importada' in pg.inner_text('#note'), n_app)
    pg.fill('#cargo', 'tecnico em seg'); pg.wait_for_timeout(80); check('CBO importada: busca funciona', 'Técnico em segurança do trabalho' in pg.locator('#occ [data-occ]').all_inner_texts())
    pg.reload(); pg.wait_for_timeout(400); check('CBO importada persiste após recarregar', pg.evaluate('cboList().length') == 30)
    (OUT / 'x.csv').write_text('a;b\n'); pg.locator('#nav button').nth(1).click(); pg.set_input_files('#cbo', str(OUT / 'x.csv')); pg.wait_for_timeout(200); check('CBO inválida: mensagem e base mantida', 'inválido' in pg.inner_text('#note') and pg.evaluate('cboList().length') == 30)
    ctx.close(); b.close()
print('\nRESUMO: %d ok, %d falhas' % (len(ok), len(fails)))
for f in fails: print(' -', f)
sys.exit(1 if fails else 0)
