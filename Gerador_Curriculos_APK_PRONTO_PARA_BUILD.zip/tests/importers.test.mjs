// Testes dos importadores e do verificador. Usam servidor HTTP local FALSO (mock) e dados FICTÍCIOS: não provam a API real do IBGE.
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import {mkdtemp, writeFile, readFile, mkdir} from 'node:fs/promises';
import {execFileSync} from 'node:child_process';
import os from 'node:os'; import path from 'node:path';
import {importarIbge} from '../scripts/import-ibge.mjs';
import {importarCbo} from '../scripts/import-cbo.mjs';
import {verificar, listarAsar, listarZip} from '../scripts/verify-artifacts.mjs';
const mudo = {log() {}, warn() {}};
const tmp = () => mkdtemp(path.join(os.tmpdir(), 'cv-'));
const UFS = 'AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' ');
const fake = (n = 6) => UFS.flatMap((u, i) => Array.from({length: n}, (_, k) => {
  const nome = `Cidade ${u} ${k}`; return i % 2 ? {nome, microrregiao: {mesorregiao: {UF: {sigla: u}}}} : {nome, 'regiao-imediata': {'regiao-intermediaria': {UF: {sigla: u}}}};
}));
const servidor = (resp) => new Promise(ok => { const s = http.createServer((q, r) => resp(q, r)).listen(0, '127.0.0.1', () => ok(s)); });
const url = s => `http://127.0.0.1:${s.address().port}/m`;

test('IBGE: repete após falhas 503 e grava municipios.js + cópia local', async () => {
  let n = 0; const s = await servidor((q, r) => { n++; if (n <= 2) { r.statusCode = 503; return r.end(); } r.end(JSON.stringify(fake())); });
  const d = await tmp(); const out = path.join(d, 'm.js'), copia = path.join(d, 'c.json');
  const r = await importarIbge({api: url(s), out, copia, tentativas: 4, esperaMs: 1, minTotal: 100, log: mudo}); s.close();
  assert.equal(n, 3); assert.equal(r.total, 162);
  const js = await readFile(out, 'utf8'); assert.match(js, /^window\.__municipios = \{/); assert.ok(JSON.parse(await readFile(copia, 'utf8')).SP.length === 6);
});
test('IBGE: API fora do ar usa a cópia local', async () => {
  const d = await tmp(), copia = path.join(d, 'c.json'), out = path.join(d, 'm.js');
  const dados = Object.fromEntries(UFS.map(u => [u, Array.from({length: 6}, (_, k) => `Cidade ${u} ${k}`)])); await writeFile(copia, JSON.stringify(dados));
  const r = await importarIbge({api: 'http://127.0.0.1:1/x', out, copia, tentativas: 1, esperaMs: 1, minTotal: 100, log: mudo});
  assert.match(r.fonte, /cópia local/); assert.equal(r.total, 162);
});
test('IBGE: sem API e sem cópia: falha quando exigido, segue quando não exigido', async () => {
  const d = await tmp(), o = {api: 'http://127.0.0.1:1/x', out: path.join(d, 'm.js'), copia: path.join(d, 'nada.json'), tentativas: 1, esperaMs: 1, minTotal: 100, log: mudo};
  await assert.rejects(importarIbge({...o, exigir: true}), /IBGE indisponível/);
  assert.equal((await importarIbge({...o, exigir: false})).fonte, 'nenhuma');
});
test('IBGE: dados incompletos (poucas UFs) são rejeitados', async () => {
  const s = await servidor((q, r) => r.end(JSON.stringify(fake().filter(m => (m.microrregiao || m['regiao-imediata']).mesorregiao?.UF.sigla !== 'SP' && m.nome !== 'x').slice(0, 30))));
  const d = await tmp();
  await assert.rejects(importarIbge({api: url(s), out: path.join(d, 'm.js'), copia: path.join(d, 'c.json'), tentativas: 1, minTotal: 100, exigir: true, log: mudo}), /IBGE indisponível/); s.close();
});
test('CBO: lê CSV Latin-1 (ocupações + sinônimos) e JSON, normaliza caixa, remove duplicados', async () => {
  const d = await tmp(), dir = path.join(d, 'cbo'); await mkdir(dir);
  const ocup = 'CODIGO;TITULO\r\n' + ['PEDREIRO', 'Auxiliar de enfermagem', 'Técnico em eletrônica', 'COZINHEIRO GERAL', 'Motorista de caminhão', 'ELETRICISTA DE MANUTENÇÃO', 'Padeiro', 'Recepcionista', 'Vendedor ambulante', 'Garçom', 'Operador de caixa'].map((t, i) => `${700000 + i};${t}`).join('\r\n');
  await writeFile(path.join(dir, 'CBO2002 - Ocupacao.csv'), Buffer.from(ocup, 'latin1'));
  await writeFile(path.join(dir, 'CBO2002 - Sinonimo.csv'), Buffer.from('CODIGO;TITULO\n715210;Pedreiro\n715210;Pedreiro de acabamento\n', 'latin1'));
  await writeFile(path.join(dir, 'extra.json'), JSON.stringify(['Cuidador de idosos']));
  const out = path.join(d, 'cbo.js'); const r = await importarCbo({dir, out, minimo: 10, log: mudo});
  const lista = JSON.parse((await readFile(out, 'utf8')).replace(/^window\.__cbo = /, '').replace(/;\s*$/, ''));
  assert.equal(r.arquivos.length, 3); assert.ok(lista.includes('Técnico em eletrônica') && lista.includes('Pedreiro') && lista.includes('Eletricista de manutenção') && lista.includes('Cuidador de idosos'));
  assert.equal(lista.filter(x => x === 'Pedreiro').length, 1); assert.ok(!lista.some(x => /^\d+$/.test(x) || /TITULO/i.test(x)));
});
test('CBO: pasta vazia segue (ou falha se exigido); arquivo com poucas linhas falha com mensagem clara', async () => {
  const d = await tmp(), dir = path.join(d, 'cbo'); await mkdir(dir);
  assert.equal((await importarCbo({dir, out: path.join(d, 'c.js'), log: mudo})).total, 0);
  await assert.rejects(importarCbo({dir, out: path.join(d, 'c.js'), exigir: true, log: mudo}), /nenhum arquivo/);
  await writeFile(path.join(dir, 'x.csv'), 'CODIGO;TITULO\n1;Ab\n'); await assert.rejects(importarCbo({dir, out: path.join(d, 'c.js'), log: mudo}), /apenas/);
});
/* ---- verificador de artefatos ---- */
const rnd = n => Buffer.alloc(n, 7);
function asar(arquivos) { const files = {}; for (const [p, size] of Object.entries(arquivos)) { let no = {files}; const partes = p.split('/'); for (const x of partes.slice(0, -1)) no = no.files[x] ??= {files: {}}; no.files[partes.at(-1)] = {size, offset: '0'}; }
  const j = Buffer.from(JSON.stringify({files}), 'utf8'), b = Buffer.alloc(16 + j.length); b.writeUInt32LE(4, 0); b.writeUInt32LE(j.length + 8, 4); b.writeUInt32LE(j.length + 4, 8); b.writeUInt32LE(j.length, 12); j.copy(b, 16); return b; }
async function montarWindows(d, {jspdf = true, ibge = true, exe = true} = {}) {
  const dir = path.join(d, 'dist-windows'); await mkdir(path.join(dir, 'win-unpacked', 'resources'), {recursive: true});
  if (exe) await writeFile(path.join(dir, 'Gerador-Curriculos-Setup-1.3.0.exe'), Buffer.concat([Buffer.from('MZ'), rnd(31 * 1024 * 1024)]));
  const a = {'web/index.html': 5000, 'web/cbo.js': 40, 'web/municipios.js': ibge ? 250000 : 80}; if (jspdf) a['web/vendor/jspdf.umd.min.js'] = 360000;
  await writeFile(path.join(dir, 'win-unpacked', 'resources', 'app.asar'), asar(a));
}
test('verificador: asar sintético é lido corretamente', () => { assert.deepEqual(listarAsar(asar({'web/a.js': 3, 'web/vendor/b.js': 9})), {'web/a.js': 3, 'web/vendor/b.js': 9}); });
test('verificador Windows: aceita pacote completo e recusa pacote sem EXE, sem jsPDF ou sem IBGE', async () => {
  let d = await tmp(); await montarWindows(d); assert.deepEqual(await verificar('windows', d, true), []);
  d = await tmp(); await montarWindows(d, {exe: false}); assert.match((await verificar('windows', d, true)).join('|'), /esperado 1 instalador/);
  d = await tmp(); await montarWindows(d, {jspdf: false}); assert.match((await verificar('windows', d, true)).join('|'), /jsPDF ausente/);
  d = await tmp(); await montarWindows(d, {ibge: false}); assert.match((await verificar('windows', d, true)).join('|'), /sem a lista do IBGE/);
});
async function montarApk(d, {jspdf = true, grande = true} = {}) {
  const w = path.join(d, 'w'), s = path.join(d, 'android', 'app', 'build', 'outputs', 'apk', 'debug'); await mkdir(path.join(w, 'assets', 'public', 'vendor'), {recursive: true}); await mkdir(s, {recursive: true});
  const f = {'AndroidManifest.xml': 100, 'classes.dex': grande ? 2_600_000 : 1000, 'assets/public/index.html': 5000, 'assets/public/cbo.js': 40, 'assets/public/municipios.js': 250000}; if (jspdf) f['assets/public/vendor/jspdf.umd.min.js'] = 360000;
  for (const [p, n] of Object.entries(f)) await writeFile(path.join(w, p), Buffer.from(Array.from({length: n}, (_, i) => (i * 31 + 7) & 255)));
  execFileSync('zip', ['-q', '-0', '-r', path.join(s, 'app-debug.apk'), '.'], {cwd: w}); return d;
}
test('verificador Android: lê APK real (zip) e detecta pacote incompleto ou pequeno', async () => {
  let d = await montarApk(await tmp()); assert.deepEqual(await verificar('android', d, true), []);
  assert.ok(listarZip(await readFile(path.join(d, 'android/app/build/outputs/apk/debug/app-debug.apk')))['classes.dex'] > 2_000_000);
  d = await montarApk(await tmp(), {jspdf: false}); assert.match((await verificar('android', d, true)).join('|'), /jsPDF ausente/);
  d = await montarApk(await tmp(), {grande: false}); assert.match((await verificar('android', d, true)).join('|'), /APK pequeno demais|pequeno/);
  assert.match((await verificar('android', await tmp(), true)).join('|'), /esperado 1 APK/);
});
test('android-version: ajusta versionName/versionCode e falha se não encontrar', async () => {
  const d = await tmp(), g = path.join(d, 'build.gradle'); await writeFile(g, 'defaultConfig {\n versionCode 1\n versionName "1.0"\n}\n');
  execFileSync(process.execPath, ['scripts/android-version.mjs', g], {env: {...process.env, VERSION_CODE: '42'}});
  const atual = JSON.parse(await readFile('package.json', 'utf8')).version;
  assert.match(await readFile(g, 'utf8'), new RegExp('versionCode 42[\\s\\S]*versionName "' + atual.replaceAll('.', '\\.') + '"'));
  await writeFile(g, 'nada'); assert.throws(() => execFileSync(process.execPath, ['scripts/android-version.mjs', g], {stdio: 'pipe'}));
});
