"""Dados FICTÍCIOS compartilhados pelos testes."""
LONG = 'Atendimento ao público com foco em resolução de problemas e organização de rotinas administrativas. ' * 12
DATA = dict(nome='Maria Aparecida de Albuquerque Nascimento Figueiredo Santos', tel='(17) 99999-9999', email='maria@gmail.com', uf='SP', cid='Penápolis', cidade='Penápolis, SP',
 tipo='Emprego efetivo', cargo='Auxiliar administrativo', resumo=LONG[:700], exp='Sim',
 jobs=[dict(empresa='Empresa Exemplo %d' % i, cargo='Auxiliar administrativo', ini='2018-0%d' % (i + 1), fim='2020-0%d' % (i + 2), atual=False, desc=LONG) for i in range(5)],
 esc='Ensino Superior completo', inst='Universidade Exemplo', curso='Administração', concl='2020', temCursos='Sim',
 cursos=[dict(nome='Excel avançado %d' % i, inst='Instituto', ano='2021') for i in range(6)],
 pick=['Comunicação', 'Organização', 'Proatividade', 'Liderança', 'Empatia'], info=['Excel', 'Word'], extraSk='Atendimento, Vendas, Negociação',
 fala='Sim', langs=[dict(l='Inglês', n='Avançado', como='Curso presencial', inst='Wizard', ano='2019')], cnh='Sim', cnhCats=['A', 'B'], tpl='classico')
