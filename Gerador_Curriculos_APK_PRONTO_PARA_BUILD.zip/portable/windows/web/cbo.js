window.__cbo = null; // O build preenche com a CBO se houver arquivos em data/cbo/.
