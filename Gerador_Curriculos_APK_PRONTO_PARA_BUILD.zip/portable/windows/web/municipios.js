window.__municipios = null; // O build tenta incluir a base oficial do IBGE aqui.
