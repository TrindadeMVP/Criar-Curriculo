module curriculos/portable

go 1.22
