# EXE portátil para Windows (edição navegador)

**O que é:** um único executável que contém os arquivos web do Gerador de Currículos e abre o aplicativo no **navegador padrão**. Não é o instalador Electron e não é um aplicativo nativo com janela própria. Foi compilado para Windows 64 bits, mas **não pôde ser executado em Windows neste ambiente Linux**.

## Como usar

1. Execute `Gerador-Curriculos-Windows-PORTATIL.exe`.
2. O navegador abre `http://127.0.0.1:47321/`.
3. **Mantenha a janela de terminal do EXE aberta enquanto usa o aplicativo.** Fechar essa janela encerra o serviço local.
4. Os currículos são salvos no armazenamento local do navegador, nesse endereço fixo, e não são enviados a servidores. Use **Exportar dados** periodicamente.
5. PDF: use a impressão do navegador e **Salvar como PDF**, pois esta compilação local não inclui jsPDF. Word (.docx): funciona offline graças ao JSZip incorporado.

O EXE só escuta a interface local `127.0.0.1`; não fica exposto à internet. Não precisa instalar Node, Electron nem Go.

**Limitações:** a lista completa do IBGE e a CBO não estão embutidas; o campo de cidade e cargo continua livre. O Chrome ou Edge é recomendado. Não é assinado digitalmente: o Windows pode apresentar aviso de reputação do SmartScreen.

## Compilar a partir do projeto-fonte

1. Instale Go 1.22+.
2. No diretório principal, execute `npm run build:portable`, que copia automaticamente `web/` e compila o Windows.

Alternativamente, copie `web/` para `portable/windows/web/` e, no diretório `portable/windows`, execute:

```bash
GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags="-s -w" -o Gerador-Curriculos-Windows-PORTATIL.exe .
```

O instalador Electron completo e o APK Android **continuam dependendo do GitHub Actions**.
