// Gerador de Currículos - edição portátil para Windows.
// Empacota os arquivos web em um EXE e os serve somente em 127.0.0.1.
// O navegador escolhido pelo usuário abre o aplicativo. Fechar este processo
// interrompe o servidor. Sem Electron, SDK Android ou dependências externas.
package main

import (
  "embed"
  "fmt"
  "io/fs"
  "log"
  "net"
  "net/http"
  "os"
  "os/exec"
  "runtime"
  "time"
)

//go:embed web
var embedded embed.FS

const address = "127.0.0.1:47321"
const healthMarker = "curriculos-portatil-v1"

func launch(url string) error {
  if os.Getenv("CURRICULOS_NO_BROWSER") == "1" { return nil }
  var cmd *exec.Cmd
  switch runtime.GOOS {
  case "windows": cmd = exec.Command("rundll32", "url.dll,FileProtocolHandler", url)
  case "darwin": cmd = exec.Command("open", url)
  default: cmd = exec.Command("xdg-open", url)
  }
  return cmd.Start()
}

func isOwnServer() bool {
  cli := http.Client{Timeout: 600 * time.Millisecond}
  r, err := cli.Get("http://" + address + "/__gerador_health")
  if err != nil { return false }
  defer r.Body.Close()
  return r.StatusCode == http.StatusOK && r.Header.Get("X-App") == healthMarker
}

func main() {
  url := "http://" + address + "/"
  listener, err := net.Listen("tcp", address)
  if err != nil {
    if isOwnServer() { _ = launch(url); fmt.Println("O Gerador já está aberto; a janela foi solicitada novamente."); return }
    fmt.Printf("A porta local %s está ocupada. Feche o programa que usa essa porta e tente novamente.\n", address)
    fmt.Print("Pressione Enter para sair: ")
    fmt.Scanln()
    return
  }
  sub, err := fs.Sub(embedded, "web")
  if err != nil { log.Fatal(err) }
  fileServer := http.FileServer(http.FS(sub))
  mux := http.NewServeMux()
  mux.HandleFunc("/__gerador_health", func(w http.ResponseWriter, r *http.Request) { w.Header().Set("X-App", healthMarker); fmt.Fprint(w, "OK") })
  mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
    if r.Host != address { http.Error(w, "Host inválido", 403); return }
    w.Header().Set("X-Content-Type-Options", "nosniff")
    w.Header().Set("Cache-Control", "no-store")
    fileServer.ServeHTTP(w,r)
  })
  server := &http.Server{Handler: mux, ReadHeaderTimeout: 5 * time.Second}
  go func() { if err := server.Serve(listener); err != nil && err != http.ErrServerClosed { log.Fatal(err) } }()
  fmt.Println("GERADOR DE CURRÍCULOS - WINDOWS PORTÁTIL")
  fmt.Println("Abrindo:", url)
  fmt.Println("Funciona sem internet. Os currículos ficam salvos no navegador deste computador.")
  fmt.Println("PDF: use 'Salvar como PDF' na impressão. Word: use o botão 'Baixar Word'.")
  fmt.Println("Para encerrar o aplicativo, feche ESTA janela de terminal.")
  if err := launch(url); err != nil { fmt.Println("Não consegui abrir o navegador automaticamente:", err, "\nAcesse o endereço acima manualmente.") }
  select {} // Mantém o servidor local disponível até que o processo seja encerrado.
}
